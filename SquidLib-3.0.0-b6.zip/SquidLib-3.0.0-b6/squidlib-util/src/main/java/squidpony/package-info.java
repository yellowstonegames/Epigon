/**
 * Utilities that don't fit elsewhere in SquidLib, like text manipulation, some interfaces, and compatibility code.
 */
package squidpony;