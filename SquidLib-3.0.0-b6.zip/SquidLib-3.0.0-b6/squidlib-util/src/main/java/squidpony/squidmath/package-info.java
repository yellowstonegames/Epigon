/**
 * A very broad package containing random number generators, geometry tools, and some classes for combinatorics.
 */
package squidpony.squidmath;