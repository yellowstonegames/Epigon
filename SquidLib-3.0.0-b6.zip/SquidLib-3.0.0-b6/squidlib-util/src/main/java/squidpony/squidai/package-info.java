/**
 * Tools for finding paths, optimizing targets for area-of-effect (AOE) abilities, and evaluating influence on a grid.
 */
package squidpony.squidai;