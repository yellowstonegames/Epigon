/**
 * Iterators that allow traversal of squidpony.squidmath.Coord points on a map's grid.
 */
package squidpony.squidgrid.iterator;