/**
 * Support code for working with tiled dungeon generation; normally only TilesetType is used outside SquidLib.
 */
package squidpony.squidgrid.mapping.styled;