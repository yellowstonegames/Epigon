package squidpony.squidgrid.mapping;

import squidpony.annotation.Beta;

/**
 * Holds a single level.
 *
 * Currently empty awaiting future mapping developments.
 *
 * @author Eben Howard - http://squidpony.com - howard@squidpony.com
 */
@Beta
public class TiledLevel {

}
