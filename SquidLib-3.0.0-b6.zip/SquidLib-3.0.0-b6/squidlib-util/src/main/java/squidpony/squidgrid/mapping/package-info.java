/**
 * Tools specifically for generating maps and placing content in them, usually working with 2D char arrays.
 */
package squidpony.squidgrid.mapping;