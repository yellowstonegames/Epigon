/**
 * Tools for working with data on a grid, including LOS and FOV; overlaps with geometry code in squidpony.squidmath .
 */
package squidpony.squidgrid;