/**
 * Annotations used elsewhere in SquidLib.
 */
package squidpony.annotation;