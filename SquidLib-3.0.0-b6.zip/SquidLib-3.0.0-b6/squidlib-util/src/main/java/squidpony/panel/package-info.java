/**
 * Interfaces for panels in GUIs/TUIs; these do not depend on any particular implementation of a color type.
 */
package squidpony.panel;